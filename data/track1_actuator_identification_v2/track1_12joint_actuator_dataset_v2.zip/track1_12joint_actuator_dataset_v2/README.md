# Berkeley Humanoid Lite — Track 1 Actuator Dataset v2

A synthesized machine-readable handoff from the v2.4.2 12-joint ST3215 identification campaign.

Revision v2 replaces the mechanically impaired original left-knee run with the final post-correction run collected after removal of an interfering long servo-horn screw. The original and intermediate left-knee runs are excluded from nominal training data and preserved only as diagnostic history in `left_knee_revision_comparison.csv` and `excluded_runs_manifest.csv`.

Start with `TRACK1_HANDOFF.md` and `track1_actuator_model.yaml`. Physical stiffness and physical damping remain explicitly unidentified because the unloaded step tests do not provide known external torque or reflected inertia.
